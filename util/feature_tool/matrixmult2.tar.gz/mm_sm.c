#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <libgen.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/wait.h>
#include <sys/time.h>

// gcc -g -Wall -lrt -o mm_sm mm_sm.c

#ifndef MIN_MATRIX_SIZE
# define MIN_MATRIX_SIZE 100
#endif // MIN_MATRIX_SIZE

#ifndef MAX_PROCS
# define MAX_PROCS 16
#endif //MAX_PROCS

#define COMMAND_ARGS "vho:s:p:"
#define MICROSECONDS_PER_SECOND 1000000.0
#define ELEMENT(_mat,_x,_y,_cols) _mat[(_x * _cols) + _y]

// Assume square matrices 

int matrix_size = MIN_MATRIX_SIZE;
int isVerbose = 0;
char shm_name[256];
int shmfd = -1;

float *lmatrix = NULL;
float *rmatrix = NULL;
float *result = NULL; 

void alloc_matrices(void);
void free_matrices(void);
void init_matrices(void);
void op_result(char *);
double elapse_time(struct timeval *, struct timeval *);


int main(int argc, char *argv[]){

  char *ofile_name = NULL;
  int max_procs = 1;
  int proc = -1;
  pid_t cpid = -1;
  struct timeval alloc_time0;
  struct timeval alloc_time1;
  struct timeval init_time0;
  struct timeval init_time1;
  struct timeval mm_time0;
  struct timeval mm_time1;
  struct timeval op_time0;
  struct timeval op_time1;
  struct timeval dealloc_time0;
  struct timeval dealloc_time1;

  {
    int c;
    while((c = getopt(argc, argv, COMMAND_ARGS)) != -1){
      switch(c) {
        case 'v':
          isVerbose++;
          break;
        case 'h':
          printf("%s %s\n", basename(argv[0]), COMMAND_ARGS);
          exit(EXIT_SUCCESS);
          break;
        case 's':
          matrix_size = atoi(optarg);
          if (isVerbose) { fprintf(stderr, "%d: setting matrix size to %d\n", __LINE__, matrix_size); }
          if (matrix_size < MIN_MATRIX_SIZE){
            matrix_size = MIN_MATRIX_SIZE;
            fprintf(stderr, "%d, Resetting matrix size to %d\n", __LINE__, matrix_size);
          }
          break;
        case 'o':
          ofile_name = optarg;
          if (isVerbose) { fprintf(stderr, "%d: output file set to %s\n", __LINE__, ofile_name ); }
          break;
        case 'p':
          max_procs = atoi(optarg);
          break;
        default:
          break;     
      }
    }
  }
  if(max_procs < 0) {
    max_procs = 1;
  }
  if(max_procs > MAX_PROCS) {
    max_procs = MAX_PROCS;
  }
  gettimeofday(&alloc_time0, NULL);
  alloc_matrices(); 
  gettimeofday(&alloc_time1, NULL);

  gettimeofday(&init_time0, NULL);
  init_matrices(); 
  gettimeofday(&init_time1, NULL);

  gettimeofday(&mm_time0, NULL);
  for (proc = 0; proc < max_procs; proc++){
    cpid = fork();
    if(cpid == 0){
      int i = -1, j = -1, k = -1; 

      if(isVerbose > 2){ fprintf(stderr, "\tchild process %d started \n", cpid); }

      for(i = proc; i < matrix_size; i += max_procs){
        for(j = 0; j < matrix_size; j++){
          for(k = 0; k < matrix_size; k++){
            //result[i][j] += lmatrix[i][k] * rmatrix[k][j];
            ELEMENT(result,i,j,matrix_size) += ELEMENT(lmatrix, i, k, matrix_size) * ELEMENT(rmatrix, k, j, matrix_size);
          }
        }
      }
      if(isVerbose > 2){ fprintf(stderr, "\tchild process %d done \n", cpid); }
      fflush(stderr);
      _exit(0);
    }
  }

  while((cpid == wait(NULL)) > 0){
    if (isVerbose){ fprintf(stderr, "\tchild process %d reaped \n", cpid); }
  }
  gettimeofday(&mm_time1, NULL);

  gettimeofday(&op_time0, NULL);
  op_result(ofile_name);
  gettimeofday(&op_time1, NULL);

  gettimeofday(&dealloc_time0, NULL);
  free_matrices();
  gettimeofday(&dealloc_time1, NULL);

  {
    double alloc_time = elapse_time(&alloc_time0, &alloc_time1);
    double init_time = elapse_time(&init_time0, &init_time1);
    double mm_time = elapse_time(&mm_time0, &mm_time1);
    double op_time = elapse_time(&op_time0, &op_time1);
    double dealloc_time = elapse_time(&dealloc_time0, &dealloc_time1);
    double mmults = (matrix_size * matrix_size) / mm_time;

    fprintf(stderr, "at\t\tit\t\tmm\t\tot\t\tdt\t\tmults/sec\tsize\n");
    fprintf(stderr, "%.6lf\t%.6lf\t%.6lf\t%.6lf\t%.6lf\t%.4lf\t%d\n", 
    alloc_time, init_time, mm_time, op_time, dealloc_time, mmults, matrix_size);
  }
  return EXIT_SUCCESS;
}

double elapse_time(struct timeval *t0, struct timeval *t1){
  
  double et = (((double) (t1->tv_usec - t0->tv_usec)) / MICROSECONDS_PER_SECOND) +
    ((double) (t1->tv_sec - t0->tv_sec));

  return et;
}

void alloc_matrices(void){

  if (isVerbose) { fprintf(stderr, "%d: allocating matrices...\n", __LINE__); }

  lmatrix = malloc(matrix_size * matrix_size * sizeof(float));
  rmatrix = malloc(matrix_size * matrix_size * sizeof(float));

  sprintf(shm_name, "%s.%s", "/SharedMemMatrixMult", getenv("LOGNAME"));
  if (shm_unlink(shm_name) != 0){
    //fprintf(stderr, "could not unlink shm file >%s<\n", shmName)
  }
  shmfd = shm_open(shm_name, (O_CREAT | O_RDWR | O_EXCL), (S_IRUSR | S_IRUSR));
  if(shmfd < 0){
    fprintf(stderr, "failed to open/create shared memory sgement >%s<\n", shm_name);
    exit(EXIT_FAILURE);
  }
  ftruncate(shmfd, matrix_size * matrix_size * sizeof(float));
  result = (float *) mmap(NULL, matrix_size * matrix_size * sizeof(float), 
                          PROT_READ | PROT_WRITE, MAP_SHARED, shmfd, 0);

  if (isVerbose > 1) { fprintf(stderr, "%d: allocation done\n", __LINE__); }
}

void free_matrices(void){
  
  if (isVerbose) { fprintf(stderr, "%d: deallocating matrices...\n", __LINE__); }

  free(lmatrix);
  free(rmatrix);

  munmap(result, matrix_size * matrix_size * sizeof(float));
  close(shmfd);
  shm_unlink(shm_name);

  lmatrix = rmatrix = result = NULL;

  if (isVerbose > 1) { fprintf(stderr, "%d: deallocation done\n", __LINE__); }
}

void init_matrices(void){

  int row = -1, col = -1;

  if (isVerbose) { fprintf(stderr, "%d: initializting matrices...\n", __LINE__); }

  for(row = 0; row < matrix_size; row++){
    for(col = 0; col < matrix_size; col++){
      ELEMENT(lmatrix,row,col,matrix_size) = (row + col) * 2.0;
      ELEMENT(rmatrix,row,col,matrix_size) = (row + col) * 3.0;
      ELEMENT(result,row,col,matrix_size) = 0.0;
    }
  }
  if (isVerbose > 1) { fprintf(stderr, "%d: initialization done\n", __LINE__); }

}

void op_result(char *ofile_name){

  int row = -1, col = -1; 
  FILE *ofile = stdout;

  if (isVerbose) { fprintf(stderr, "%d: output result to file %s\n\n", __LINE__, 
    ofile_name ? ofile_name : "stdout"); }

  if(ofile_name != NULL){
    ofile = fopen(ofile_name, "w");
    if (ofile == NULL){
      perror("could not open output file");
      fprintf(stderr, "Failed to open output file:  %s\n", ofile_name);
      exit(1);
    }
  }

  for(row = 0; row < matrix_size; row++){
    for(col = 0; col < matrix_size; col++){
      fprintf(ofile, "%.2f ", ELEMENT(result, row, col, matrix_size));
    }
    fprintf(ofile, "\n");
  }
  if(ofile_name != NULL){
    fclose(ofile);
  }

  if (isVerbose > 1) { fprintf(stderr, "%d: output complete\n", __LINE__); }
}